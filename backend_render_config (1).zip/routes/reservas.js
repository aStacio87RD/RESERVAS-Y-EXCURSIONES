const express = require('express');
const router = express.Router();
const pool = require('../db');

router.post('/', async (req, res) => {
  const { nombre, email, adultos, ninos, entrada, salida, comentarios, excursiones } = req.body;
  const result = await pool.query(
    'INSERT INTO reservas (nombre, email, adultos, ninos, entrada, salida, comentarios) VALUES ($1, $2, $3, $4, $5, $6, $7) RETURNING id',
    [nombre, email, adultos, ninos, entrada, salida, comentarios]
  );
  const reservaId = result.rows[0].id;
  for (let ex of excursiones) {
    await pool.query('INSERT INTO reserva_excursion (reserva_id, excursion_id) VALUES ($1, $2)', [reservaId, ex]);
  }
  res.json({ reservaId });
});

module.exports = router;
