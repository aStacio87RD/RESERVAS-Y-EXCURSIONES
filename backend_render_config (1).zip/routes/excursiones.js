const express = require('express');
const router = express.Router();
const pool = require('../db');
const auth = require('../auth');

router.get('/', async (_, res) => {
  const result = await pool.query('SELECT * FROM excursiones');
  res.json(result.rows);
});

router.post('/', auth, async (req, res) => {
  const { nombre, descripcion, precio } = req.body;
  await pool.query(
    'INSERT INTO excursiones (nombre, descripcion, precio) VALUES ($1, $2, $3)',
    [nombre, descripcion, precio]
  );
  res.sendStatus(201);
});

router.put('/:id', auth, async (req, res) => {
  const { nombre, descripcion, precio } = req.body;
  await pool.query(
    'UPDATE excursiones SET nombre = $1, descripcion = $2, precio = $3 WHERE id = $4',
    [nombre, descripcion, precio, req.params.id]
  );
  res.sendStatus(200);
});

router.delete('/:id', auth, async (req, res) => {
  await pool.query('DELETE FROM excursiones WHERE id = $1', [req.params.id]);
  res.sendStatus(200);
});

module.exports = router;
