const express = require('express');
const router = express.Router();
const stripe = require('stripe')(process.env.STRIPE_SECRET_KEY);
const mercadopago = require('mercadopago');
const paypal = require('paypal-rest-sdk');
const pool = require('../db');

mercadopago.configure({ access_token: process.env.MERCADOPAGO_ACCESS_TOKEN });

paypal.configure({
  mode: process.env.PAYPAL_MODE,
  client_id: process.env.PAYPAL_CLIENT_ID,
  client_secret: process.env.PAYPAL_CLIENT_SECRET
});

router.post('/crear-checkout-stripe', async (req, res) => {
  const { reservaId } = req.body;
  const session = await stripe.checkout.sessions.create({
    line_items: [{ price_data: { currency: 'usd', product_data: { name: 'Reserva Hotel' }, unit_amount: 5000 }, quantity: 1 }],
    mode: 'payment',
    success_url: 'https://tusitio.com/success',
    cancel_url: 'https://tusitio.com/cancel'
  });
  res.json({ url: session.url });
});

router.post('/crear-preferencia-mercadopago', async (req, res) => {
  const { reservaId } = req.body;
  const preference = await mercadopago.preferences.create({
    items: [{ title: 'Reserva Hotel', quantity: 1, unit_price: 50 }],
    back_urls: { success: 'https://tusitio.com/success', failure: 'https://tusitio.com/cancel' },
    auto_return: 'approved'
  });
  res.json({ url: preference.body.init_point });
});

router.post('/crear-checkout-paypal', async (req, res) => {
  const { reservaId } = req.body;
  const payment = {
    intent: 'sale',
    payer: { payment_method: 'paypal' },
    redirect_urls: {
      return_url: 'https://tusitio.com/success',
      cancel_url: 'https://tusitio.com/cancel'
    },
    transactions: [{
      amount: { currency: 'USD', total: '50.00' },
      description: 'Reserva Hotel'
    }]
  };
  paypal.payment.create(payment, (err, payment) => {
    if (err) return res.status(500).send(err);
    const url = payment.links.find(link => link.rel === 'approval_url').href;
    res.json({ url });
  });
});

module.exports = router;
